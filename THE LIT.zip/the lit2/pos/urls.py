from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('sales/', views.sales_view, name='sales'),
    path('product_management/', views.product_management_view, name='product_management'),
    path("add-product/", views.add_product, name="add_product"),

]
