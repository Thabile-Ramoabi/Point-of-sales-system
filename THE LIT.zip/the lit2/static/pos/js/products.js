// Sidebar toggle logic
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    const toggleBtn = document.getElementById('sidebarToggle');

    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('expanded');
        mainContent.classList.toggle('shifted');
    });

    // Close modals when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function (e) {
            if (e.target === this) {
                this.classList.add('hidden');
            }
        });
    });
});

// Show Add Product Modal
function showAddProductModal() {
    document.getElementById('addProductModal').classList.remove('hidden');
}

// Hide Add Product Modal
function hideAddProductModal() {
    document.getElementById('addProductModal').classList.add('hidden');
}

// Show Edit Product Modal
function showEditProductModal(productId) {
    fetch(`/api/products/${productId}/`)
        .then(response => response.json())
        .then(product => {
            document.getElementById('edit_id').value = product.id;
            document.getElementById('edit_name').value = product.name;
            document.getElementById('edit_category').value = product.category;
            document.getElementById('edit_description').value = product.description;
            document.getElementById('edit_quantity').value = product.quantity;
            document.getElementById('edit_unit_price').value = product.unit_price;
            document.getElementById('edit_cost_price').value = product.cost_price;

            if (product.image) {
                document.getElementById('edit_image_preview').src = product.image;
            } else {
                document.getElementById('edit_image_preview').src = "{% static 'images/no-image.png' %}";
            }

            document.getElementById('editProductForm').action = `/products/${productId}/update/`;
            document.getElementById('editProductModal').classList.remove('hidden');
        });
}

// Hide Edit Product Modal
function hideEditProductModal() {
    document.getElementById('editProductModal').classList.add('hidden');
}

// Preview image when editing
function previewEditImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById('edit_image_preview').src = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
}

// Confirm product deletion
function confirmDelete(productId) {
    if (confirm('Are you sure you want to delete this product?')) {
        fetch(`/products/${productId}/delete/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': '{{ csrf_token }}',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        }).then(response => {
            if (response.ok) {
                location.reload();
            }
        });
    }
}

// Modal toggle logic
const openAddModal = document.getElementById("openAddModal");
const closeAddModal = document.getElementById("closeAddModal");
const modal = document.getElementById("addProductModal");

openAddModal.addEventListener("click", () => modal.classList.remove("hidden"));
closeAddModal.addEventListener("click", () => modal.classList.add("hidden"));

// Handle Add Product Form
document.getElementById("addProductForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);
    const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]').value;

    const response = await fetch("/add-product/", {
        method: "POST",
        headers: {
            "X-CSRFToken": csrfToken
        },
        body: formData,
    });

    if (response.ok) {
        const data = await response.json();
        modal.classList.add("hidden");
        form.reset();

        const table = document.getElementById("productsTableBody");
        const row = document.createElement("tr");

        row.innerHTML = `
            <td class="py-2 px-4">${data.name}</td>
            <td class="py-2 px-4">₱${parseFloat(data.price).toFixed(2)}</td>
            <td class="py-2 px-4 ${data.quantity < 20 ? 'text-red-500 font-bold' : ''}">${data.quantity}</td>
        `;
        table.appendChild(row);
    } else {
        alert("Failed to add product.");
    }
});
