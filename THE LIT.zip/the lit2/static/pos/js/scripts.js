// Sidebar toggle
document.querySelector('.menu-btn').addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('open');
  });
  
  // Tab switching
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
  
      const target = btn.dataset.target;
      document.querySelectorAll('.tab-content').forEach(tab => {
        tab.style.display = tab.id === target ? 'grid' : 'none';
      });
    });
  });
  
  // Popup control
  const popup = document.querySelector('.popup');
  document.querySelectorAll('.item-card').forEach(card => {
    card.addEventListener('click', () => {
      // Load data into popup
      const name = card.dataset.name;
      const image = card.dataset.image;
  
      popup.querySelector('.popup-title').textContent = name;
      popup.querySelector('.popup-img').src = image;
      popup.dataset.itemId = card.dataset.id;
      popup.style.display = 'flex';
    });
  });
  
  document.querySelector('.popup-close').addEventListener('click', () => {
    popup.style.display = 'none';
  });
  
  // Quantity control
  let quantity = 1;
  const qtyDisplay = document.querySelector('.quantity-value');
  
  document.querySelector('.qty-plus').addEventListener('click', () => {
    quantity++;
    qtyDisplay.textContent = quantity;
  });
  
  document.querySelector('.qty-minus').addEventListener('click', () => {
    if (quantity > 1) quantity--;
    qtyDisplay.textContent = quantity;
  });
  
  // Toggle favorite
  document.querySelector('.star-toggle').addEventListener('click', () => {
    const isFav = popup.classList.toggle('favorite');
    // You can later send this to backend using AJAX
  });
  
  // Add to cart
  document.querySelector('.add-to-cart-btn').addEventListener('click', () => {
    const itemName = popup.querySelector('.popup-title').textContent;
    const cart = document.querySelector('.cart-items');
  
    const newItem = document.createElement('div');
    newItem.classList.add('cart-item');
    newItem.innerHTML = `
      <input type="checkbox" checked>
      <span>${itemName}</span>
      <span class="cart-qty">x${quantity}</span>
    `;
    cart.appendChild(newItem);
  
    popup.style.display = 'none';
    quantity = 1;
    qtyDisplay.textContent = quantity;
  });

  // Get elements
const modal = document.getElementById("productModal");
const modalImage = document.getElementById("modalImage");
const modalTitle = document.getElementById("modalTitle");
const modalDescription = document.getElementById("modalDescription");
const modalQty = document.getElementById("modalQty");

let currentQty = 1;

// Handle click on product card
document.querySelectorAll(".product-card").forEach(card => {
  card.addEventListener("click", () => {
    // You can customize this to pull real data
    const img = card.querySelector("img").src;
    const title = card.querySelector("h3").textContent;
    
    modalImage.src = img;
    modalTitle.textContent = title;
    modalDescription.textContent = "This is a placeholder description.";
    currentQty = 1;
    modalQty.textContent = currentQty;
    modal.style.display = "block";
  });
});

// Quantity buttons
document.getElementById("increaseQty").addEventListener("click", () => {
  currentQty++;
  modalQty.textContent = currentQty;
});

document.getElementById("decreaseQty").addEventListener("click", () => {
  if (currentQty > 1) currentQty--;
  modalQty.textContent = currentQty;
});

// Close modal
document.querySelector(".close-btn").addEventListener("click", () => {
  modal.style.display = "none";
});

window.addEventListener("click", e => {
  if (e.target === modal) modal.style.display = "none";
});



document.addEventListener('DOMContentLoaded', function () {
  const modal = document.getElementById('productModal');
  const closeBtn = document.querySelector('.close-btn');
  const modalImage = document.getElementById('modalImage');
  const modalName = document.getElementById('modalName');

  // Example: all product cards have class 'product-card'
  document.querySelectorAll('.product-card').forEach(card => {
    card.addEventListener('click', () => {
      const name = card.getAttribute('data-name') || 'Sample Item';
      const img = card.getAttribute('data-img') || 'default.png';

      modalName.textContent = name;
      modalImage.src = `/static/img/${img}`; // Adjust path if needed
      modal.style.display = 'block';
    });
  });

  closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  window.addEventListener('click', e => {
    if (e.target == modal) {
      modal.style.display = 'none';
    }
  });
});
