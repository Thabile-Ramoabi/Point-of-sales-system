// Enhanced Product Management JS with consistent modal handling

document.addEventListener('DOMContentLoaded', function () {
    // Sidebar elements
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    const toggleBtn = document.getElementById('sidebarToggle');
    
    // Modal elements
    const openAddModal = document.getElementById("openAddModal");
    const closeAddModal = document.getElementById("closeAddModal");
    const cancelAddModal = document.getElementById("cancelAddModal");
    const modal = document.getElementById("addProductModal");

    // 1. Sidebar toggle functionality
    toggleBtn?.addEventListener('click', () => {
        sidebar?.classList.toggle('expanded');
        mainContent?.classList.toggle('shifted');
    });

    // 2. Modal control functions
    const showModal = () => {
        modal?.classList.remove('hidden');
        modal?.classList.add('show');
    };

    const hideModal = () => {
        modal?.classList.add('hidden');
        modal?.classList.remove('show');
    };

    // 3. Modal event listeners
    openAddModal?.addEventListener("click", (e) => {
        e.stopPropagation();
        showModal();
    });

    closeAddModal?.addEventListener("click", hideModal);
    cancelAddModal?.addEventListener("click", hideModal);

    // Close modal when clicking outside
    modal?.addEventListener('click', function (e) {
        if (e.target === this) {
            hideModal();
        }
    });

    // 4. Form submission handler
    const addProductForm = document.getElementById("addProductForm");
    addProductForm?.addEventListener("submit", async function (e) {
        e.preventDefault();

        const formData = new FormData(addProductForm);
        const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]').value;

        try {
            const response = await fetch("/add-product/", {
                method: "POST",
                headers: {
                    "X-CSRFToken": csrfToken
                },
                body: formData,
            });

            if (response.ok) {
                const data = await response.json();
                hideModal();
                addProductForm.reset();

                // Update table with new product
                const table = document.getElementById("productsTableBody");
                if (table) {
                    const row = document.createElement("tr");
                    row.className = data.quantity < 20 ? 'low-stock' : '';
                    row.innerHTML = `
                        <td>
                            ${data.image ? `<img src="${data.image.url}" alt="${data.name}" class="product-thumbnail">` : '<div class="no-image">No image</div>'}
                        </td>
                        <td>${data.name}</td>
                        <td>${data.price}</td>
                        <td>${data.quantity}</td>
                        <td>
                            <button class="action-btn edit-btn" onclick="editProduct(event, ${data.id})">✎</button>
                            <button class="action-btn delete-btn" onclick="deleteProduct(event, ${data.id})">🗑</button>
                        </td>
                    `;
                    table.appendChild(row);
                }
            } else {
                alert("Failed to add product. Please try again.");
            }
        } catch (error) {
            console.error("Error:", error);
            alert("An error occurred while adding the product.");
        }
    });
});

// Edit Product Functions
function editProduct(e, productId) {
    e.stopPropagation();
    fetch(`/api/products/${productId}/`)
        .then(response => response.json())
        .then(product => {
            // Populate edit form fields
            document.getElementById('edit_id').value = product.id;
            document.getElementById('edit_name').value = product.name;
            document.getElementById('edit_category').value = product.category;
            document.getElementById('edit_description').value = product.description;
            document.getElementById('edit_quantity').value = product.quantity;
            document.getElementById('edit_unit_price').value = product.unit_price;
            document.getElementById('edit_cost_price').value = product.cost_price;

            // Handle image preview
            const preview = document.getElementById('edit_image_preview');
            if (product.image) {
                preview.src = product.image;
                preview.style.display = 'block';
            } else {
                preview.style.display = 'none';
            }

            // Show edit modal
            document.getElementById('editProductModal').classList.remove('hidden');
            document.getElementById('editProductModal').classList.add('show');
        })
        .catch(error => {
            console.error("Error fetching product:", error);
            alert("Failed to load product details.");
        });
}

function hideEditProductModal() {
    document.getElementById('editProductModal').classList.add('hidden');
    document.getElementById('editProductModal').classList.remove('show');
}

function previewEditImage(input) {
    const preview = document.getElementById('edit_image_preview');
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function deleteProduct(e, productId) {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this product?')) {
        fetch(`/products/${productId}/delete/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        }).then(response => {
            if (response.ok) {
                location.reload();
            } else {
                alert("Failed to delete product.");
            }
        }).catch(error => {
            console.error("Error deleting product:", error);
            alert("An error occurred while deleting the product.");
        });
    }
}


// Get modal elements
const modal = document.getElementById('productModal');
const modalTitle = document.getElementById('modalTitle');
const modalImage = document.getElementById('modalImage');
const closeModal = document.getElementById('closeModal');
const quantityValue = document.getElementById('quantityValue');
const increaseQty = document.getElementById('increaseQty');
const decreaseQty = document.getElementById('decreaseQty');
const addToCartBtn = document.getElementById('addToCartBtn');

let currentProduct = null;
let quantity = 1;

// Open modal on product click
document.querySelectorAll('.product-card').forEach(card => {
  card.addEventListener('click', () => {
    const name = card.getAttribute('data-name');
    const imgSrc = card.getAttribute('data-img');

    currentProduct = name;
    modalTitle.textContent = name;
    modalImage.src = imgSrc;
    quantity = 1;
    quantityValue.textContent = quantity;

    modal.style.display = 'block';
  });
});

// Close modal
closeModal.addEventListener('click', () => {
  modal.style.display = 'none';
});

// Quantity increase/decrease
increaseQty.addEventListener('click', () => {
  quantity++;
  quantityValue.textContent = quantity;
});

decreaseQty.addEventListener('click', () => {
  if (quantity > 1) {
    quantity--;
    quantityValue.textContent = quantity;
  }
});

// Handle Add to Cart
addToCartBtn.addEventListener('click', () => {
  console.log(`Added ${quantity} x ${currentProduct} to cart.`);
  // You can trigger your cart update logic here
  modal.style.display = 'none';
});
